from textual import work
from textual.app import App
from textual.binding import Binding
from textual.containers import Horizontal
from textual.message import Message
from textual.widgets import Footer, Header

from ..audio.analyzer import SpectrumAnalyzer
from ..models import Library
from ..models.cover import find_cover
from ..player import Player, PlayerState
from .cover import CoverScreen, CoverView
from .widgets import LibraryTree, NowPlaying, QueueView

SEEK_STEP = 5      # sekund
VOLUME_STEP = 5    # prosent


class BackendEvent(Message):
    """Carries a callback from the audio thread over to the UI thread."""

    def __init__(self, callback):
        super().__init__()
        self.callback = callback


class MusicPlayerApp(App):
    """The terminal music player."""

    CSS_PATH = "app.tcss"
    TITLE = "Musikkspelar"

    BINDINGS = [
        # priority=True: tastane skal verke same kva panel som har fokus
        Binding("space", "toggle_pause", "Play/pause", priority=True),
        Binding("n", "next", "Neste", priority=True),
        Binding("p", "previous", "Førre", priority=True),
        Binding("left", "seek(-1)", "Spol -5s", show=False, priority=True),
        Binding("right", "seek(1)", "Spol +5s", show=False, priority=True),
        Binding("plus,equals_sign", "volume(1)", "Volum +", show=False),
        Binding("minus", "volume(-1)", "Volum -", show=False),
        Binding("s", "shuffle", "Stokk"),
        Binding("r", "repeat", "Gjenta"),
        Binding("v", "toggle_spectrum", "Spekter"),
        Binding("i", "show_cover", "Cover"),
        Binding("c", "clear_queue", "Tøm kø", show=False),
        Binding("q", "quit", "Avslutt"),
    ]

    def __init__(self, music_folder, backend):
        super().__init__()
        self.backend_name = type(backend).__name__.removesuffix("Backend").lower()
        self.library = Library(music_folder, backend.SUPPORTED_EXTENSIONS)
        # Hendingar frå lydmotoren kjem i ein annan tråd. post_message er trådtrygg
        # og blokkerer ikkje, så vi sender dei vidare som meldingar.
        self.player = Player(backend, dispatch=lambda callback: self.post_message(BackendEvent(callback)))
        self.player.add_listener(self.refresh_views)
        self.analyzer = SpectrumAnalyzer()
        self.player.add_listener(self._prepare_spectrum)
        self.player.add_listener(self._update_cover)
        self._cover_track = None

    def compose(self):
        yield Header(show_clock=True)
        with Horizontal(id="main"):
            yield LibraryTree(id="library")
            yield QueueView(id="queue")
        yield NowPlaying(spectrum_source=self._spectrum_levels, id="now-playing")
        yield Footer()

    def on_mount(self):
        self.sub_title = f"Skannar {self.library.root} …"
        self.player.volume = 80
        self.set_interval(0.25, self._tick)
        self.scan_library()

    def on_unmount(self):
        self.player.close()

    @work(thread=True, exclusive=True)
    def scan_library(self):
        self.library.scan()
        self.call_from_thread(self._library_loaded)

    def _library_loaded(self):
        tree = self.query_one(LibraryTree)
        tree.load(self.library)
        tree.focus()
        self.sub_title = f"{self.library.root} · {self.backend_name}"
        if self.library.errors:
            self.notify(f"{len(self.library.errors)} filer kunne ikkje lesast", severity="warning")
        if not len(self.library):
            self.notify("Fann ingen musikkfiler i mappa", severity="error", timeout=10)

    # --- Oppdatering av visninga --------------------------------------

    def refresh_views(self):
        self.query_one(NowPlaying).show(self.player)
        playing = self.player.queue.current_index if self.player.current_track else None
        self.query_one(QueueView).show(self.player.queue, playing)

    def _tick(self):
        self.query_one(NowPlaying).update_time(self.player)

    # --- Albumcover ----------------------------------------------------

    def _update_cover(self):
        track = self.player.current_track
        if track is self._cover_track:
            return
        self._cover_track = track
        data = find_cover(track.path) if track else None
        self.query_one("#np-cover", CoverView).set_image(data)

    def action_show_cover(self):
        track = self.player.current_track
        if track is None:
            self.notify("Ingenting spelar", timeout=2)
            return
        year = f" ({track.year})" if track.year else ""
        self.push_screen(CoverScreen(find_cover(track.path), track.album, f"{track.artist} — {track.album}{year}"))

    # --- Visualisering -------------------------------------------------

    def _prepare_spectrum(self):
        """Decodes the current and the next track in advance, so the bars are ready in time."""
        for track in (self.player.current_track, self.player.queue.peek_next()):
            if track is not None:
                self.analyzer.prepare(track.path)

    def _spectrum_levels(self, bands):
        track = self.player.current_track
        if track is None or self.player.state is not PlayerState.PLAYING:
            return None  # søylene fell ned til null
        return self.analyzer.levels(track.path, self.player.position, bands)

    # --- Meldingar frå widgets og lydmotoren --------------------------

    def on_backend_event(self, message):
        message.callback()

    def on_library_tree_play_requested(self, message):
        self.player.play_tracks(message.tracks, message.start_index)

    def on_library_tree_enqueue_requested(self, message):
        self.player.enqueue(message.tracks)
        self.notify(f"La til {len(message.tracks)} låt(ar) i køen", timeout=2)

    def on_queue_view_play_index_requested(self, message):
        self.player.play_queue_index(message.index)

    def on_queue_view_remove_requested(self, message):
        self.player.remove_from_queue(message.index)

    def on_progress_line_seek_requested(self, message):
        if self.player.duration:
            self.player.seek(message.fraction * self.player.duration, absolute=True)

    # --- Handlingar (tastatur) -----------------------------------------

    def action_toggle_pause(self):
        self.player.toggle_pause()

    def action_next(self):
        self.player.next()

    def action_previous(self):
        self.player.previous()

    def action_seek(self, direction):
        self.player.seek(direction * SEEK_STEP)
        self._tick()

    def action_volume(self, direction):
        self.player.volume = self.player.volume + direction * VOLUME_STEP

    def action_shuffle(self):
        self.player.toggle_shuffle()

    def action_repeat(self):
        self.player.cycle_repeat()

    def action_toggle_spectrum(self):
        self.query_one(NowPlaying).toggle_spectrum()

    def action_clear_queue(self):
        self.player.clear_queue()
